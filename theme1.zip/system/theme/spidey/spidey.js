function changeBackgroundColorsAndImages() {
  var elements1 = document.querySelectorAll('[style*="background: #fff4ec"]');
  var elements2 = document.querySelectorAll('[style*="background: rgba(225, 230, 228, 0.8)"]');
  var images = document.querySelectorAll('img[src="./images/logo.png"]');
  var olexosLogo = document.getElementById('olexoslogo');

  elements1.forEach(function(element) {
    element.style.background = '#FE8181';
  });

  elements2.forEach(function(element) {
    element.style.background = 'rgba(219, 182, 180, 0.8)';
  });

  images.forEach(function(image) {
    image.src = './system/theme/spidey/spideylogo.png';
  });

  if (olexosLogo) {
    olexosLogo.src = './system/theme/spidey/spideylogo.png';
  }
}


    function themedarkmode() {
      var isDarkmodeEnabled = localStorage.getItem("isDarkmodeEnabled");
      if (isDarkmodeEnabled === "true") {
        localStorage.setItem("isDarkmodeEnabled", "false");
        window.open('./olex.html','_self');
      }
    }

window.open('./system/theme/spidey/spidey.html','theme');
changeBackgroundColorsAndImages();
themedarkmode();


var style = document.createElement("style");
document.body.appendChild(style);
  style.innerHTML = `
.link2 {
font-family: 'Montserrat', sans-serif;
	margin-top: 5px;
	margin-right: 2px;
	border-radius: 20px;
	padding: 7px;
	border: solid 0px black; 
background-color: #FECECE;
      width:100px;
      height:80px;
  overflow: scroll; /* enable scrolling */
  scrollbar-width: none; /* hide scrollbar for Firefox */
  -ms-overflow-style: none; /* hide scrollbar for IE and Edge */
transition: box-shadow .3s;
transition: 0.3s;
  display: inline-block;
cursor: default;
}

    #loading-screen {
background-image: url("./system/theme/spidey/spideybg.jpg");
    }
`;
  document.body.appendChild(style);
