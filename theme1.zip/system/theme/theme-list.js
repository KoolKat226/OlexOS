document.addEventListener("DOMContentLoaded", function() {
    var appList = document.getElementById("app-list");
    var appIframe = document.getElementById("app-iframe");
    var popup = document.getElementById("popup");
    var popupText = document.getElementById("popup-text");
    var popupButton = document.getElementById("popup-button");
    var button2 = document.getElementById("button2");

    // Create the list of widgets
    appLinks.forEach(function(widget) {
        var listItem = document.createElement("li");
        listItem.classList.add("widget-item");

        // Create the preview image
        var image = document.createElement("img");
        image.alt = widget.name + " Preview";
        image.classList.add("widget-preview");

        // Add error event listener to handle image load failure
        image.addEventListener("error", function() {
            image.style.display = "none";
        });

        // Set the image source after attaching the event listener
        image.src = widget.image;

        listItem.appendChild(image);

        // Create the widget button
        var divButton = document.createElement("div");
        divButton.textContent = widget.name;
        divButton.classList.add("widget-button");
        divButton.style.display = "flex";
        divButton.style.alignItems = "center";
        divButton.style.justifyContent = "center";
        listItem.appendChild(divButton);

        appList.appendChild(listItem);

        // Handle button click event
        divButton.addEventListener("click", function() {
            showPopup("Theme Set! Reboot for full experience");
            // Save the widget link in localStorage
            localStorage.setItem("OlexOStheme", widget.link);

            // Open the widget link in a new tab
            window.open(widget.link, "theme");

            // Display the iframe with the widget link
            appIframe.src = widget.link;
            appIframe.style.display = "block";
        });
    });

    // Handle button2 click event
    button2.addEventListener("click", function() {
        showPopup("App Installed! Refresh your app library to play");
    });

    // Close the popup when the OK button is clicked
    popupButton.addEventListener("click", function() {
        popup.style.display = "none";
    });

    // Check if a widget link is stored in localStorage and display the iframe if present
    var storedLink = localStorage.getItem("OlexOStheme");
    if (storedLink) {
        appIframe.src = storedLink;
        appIframe.style.display = "block";
    }

    // Function to display the popup with a given message
    function showPopup(message) {
        popupText.textContent = message;
        popup.style.display = "block";
    }
});
document.addEventListener("DOMContentLoaded", function() {
    var appIframe = document.getElementById("app-iframe");
    var toggleButton = document.getElementById("audio-toggle");
    var audioElement = null;

    // Check if a widget link is stored in localStorage
    var storedLink = localStorage.getItem("OlexOStheme");
    if (storedLink) {
        appIframe.src = storedLink;
        appIframe.style.display = "block";
        if (isAudioEnabled()) {
            playAudio(storedLink);
            toggleButton.textContent = "Disable Audio";
        } else {
            toggleButton.textContent = "Enable Audio";
        }
    }

    // Toggle audio when the button is clicked
    toggleButton.addEventListener("click", function() {
        if (isAudioEnabled()) {
            disableAudio();
            stopAudio();
        } else {
            enableAudio();
            playAudio(storedLink);
        }
        updateToggleButton();
    });

    // Function to play audio based on the app link
    function playAudio(appLink) {
        var appDetails = appLinks.find(function(app) {
            return app.link === appLink;
        });

        if (appDetails && appDetails.audio) {
            audioElement = new Audio(appDetails.audio);
            audioElement.play();
        }
    }

    // Function to stop audio playback
    function stopAudio() {
        if (audioElement) {
            audioElement.pause();
            audioElement.currentTime = 0;
            audioElement = null;
        }
    }

    // Function to check if audio is enabled
    function isAudioEnabled() {
        var audioEnabled = localStorage.getItem("audioEnabled");
        return audioEnabled === "true";
    }

    // Function to enable audio
    function enableAudio() {
        localStorage.setItem("audioEnabled", "true");
    }

    // Function to disable audio
    function disableAudio() {
        localStorage.setItem("audioEnabled", "false");
    }

    // Function to update the toggle button text based on audio state
    function updateToggleButton() {
        if (isAudioEnabled()) {
            toggleButton.textContent = "Disable Audio";
        } else {
            toggleButton.textContent = "Enable Audio";
        }
    }
});

