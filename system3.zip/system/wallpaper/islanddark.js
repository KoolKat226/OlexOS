
var div = document.createElement("div");
document.body.appendChild(div);
  div.innerHTML = `
	<style type="text/css">
.bg {
  /* The image used */
  background-image: url("./islanddark.png");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

  
	</style>



  `;
document.body.appendChild(div);
