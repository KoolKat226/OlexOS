var button2 = document.getElementById("button2");
var link2Name = document.getElementById("link2-name");
var link2Url = document.getElementById("link2");
var link2Target = document.getElementById("link2-target");
var display2 = document.getElementById("display2");

button2.addEventListener('click', () => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks2 === null) {
    links2 = [];
  } else {
    links2 = locallinks2;
  }

  links2.push("<a " + link2Url.value + " target=" + link2Target.value + ">" + link2Name.value + "</a>");
  localStorage.setItem('locallink2', JSON.stringify(links2));

  showlink2();

  link2Url.value = "";
  link2Name.value = "";

  refreshDisplay(); // Call the refreshDisplay function after updating the data
});


const showlink2 = () => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks2 === null) {
    links2 = [];
  } else {
    links2 = locallinks2;
  }

  let link2 = '';
  links2.forEach((data, index) => {
    link2 += `<div class="link-group"><button class="link2" draggable="true" ondragstart="dragStart(event)" ondragover="dragOver(event)" ondrop="drop(event)" ondragend="reorderLinks()">${data}</button><button class="delete" onClick="deletelink2(${index})">×</button></div>`;
  });

  display2.innerHTML = link2;
};


const reorderLinks = () => {
  const linkGroups = document.getElementsByClassName("link-group");
  const updatedLinks = [];

  for (let i = 0; i < linkGroups.length; i++) {
    const linkData = linkGroups[i].querySelector('.link2').innerHTML;
    updatedLinks.push(linkData);
  }

  localStorage.setItem('locallink2', JSON.stringify(updatedLinks));
};


const deletelink2 = (index) => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  links2.splice(index, 1);
  localStorage.setItem('locallink2', JSON.stringify(links2));
  showlink2();
  loadFunction();
};

document.addEventListener('DOMContentLoaded', () => {
  refreshDisplay();
});

const refreshDisplay = () => {
  var updatedData = JSON.parse(localStorage.getItem('locallink2'));

  display2.innerHTML = '';

  if (updatedData) {
    updatedData.forEach((data, index) => {
      display2.innerHTML += `<button class="link2" draggable="true" ondragstart="dragStart(event)" ondragover="dragOver(event)" ondrop="drop(event)" ondragend="reorderLinks()">${data}</button><button class="delete" onClick="deletelink2(${index})">×</button>`;
    });
  }

  showlink2();
  loadFunction();
};

window.addEventListener('storage', () => {
  refreshDisplay();
  loadFunction();
});

let dragSrcElement = null;

function dragStart(event) {
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', event.target.innerHTML);
  dragSrcElement = event.target;
}

function dragOver(event) {
  event.preventDefault();
  event.dataTransfer.dropEffect = 'move';
}

function drop(event) {
  event.preventDefault();
  const data = event.dataTransfer.getData('text/plain');
  const dropTarget = event.target.closest('.link-group');

  if (dragSrcElement !== dropTarget) {
    const dropTargetIndex = Array.from(display2.children).indexOf(dropTarget);
    const dragSrcIndex = Array.from(display2.children).indexOf(dragSrcElement.closest('.link-group'));

    if (dragSrcIndex < dropTargetIndex) {
      display2.insertBefore(dragSrcElement.closest('.link-group'), dropTarget.nextSibling);
    } else {
      display2.insertBefore(dragSrcElement.closest('.link-group'), dropTarget);
    }

    reorderLinks();
  }
}


// Function loadFunction() and other code
function loadFunction() {
  // Your code for loadFunction()
}
