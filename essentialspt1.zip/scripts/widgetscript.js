var button2 = document.getElementById("button2");
var link2Name = document.getElementById("link2-name");
var link2Url = document.getElementById("link2");
var link2Target = document.getElementById("link2-target");
var display2 = document.getElementById("display2");

button2.addEventListener('click', () => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks2 === null) {
    links2 = [];
  } else {
    links2 = locallinks2;
  }

  links2.push("<a " + link2Url.value + " target=" + link2Target.value + ">" + link2Name.value + "</a>");
  localStorage.setItem('locallink2', JSON.stringify(links2));

  showlink2();

  link2Url.value = "";
  link2Name.value = "";

  refreshDisplay(); // Call the refreshDisplay function after updating the data
});


const showlink2 = () => {
	let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
	if(locallinks2 === null){
		links2 = []
	} else {
		links2 = locallinks2; 
	}
	
	let link2 = ''; 
	links2.forEach((data, index) => {
		link2 += `<button class="link2">${data}</button><button class="delete" onClick="deletelink2(${index})">×</button>‏‏‎‎`
	});
	
	display2.innerHTML = link2; 
}

const deletelink2 = (index) => {
	let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
	links2.splice(index, 1);
	localStorage.setItem('locallink2', JSON.stringify(links2)); 
	showlink2();
}

// Function to refresh the data in the display
const refreshDisplay = () => {
  // Retrieve the updated data from local storage
  var updatedData = localStorage.getItem('locallink2');

  // Clear the existing content in the display
  display2.innerHTML = '';

  // Populate the refreshed data into the display
  if (updatedData) {
    display2.innerHTML = updatedData;
  }

  // Call the showlink2 function again to reattach event listeners
  showlink2();
}

showlink2();
