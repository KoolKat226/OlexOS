// Define a function to save shortcuts to localStorage
function saveShortcuts(shortcuts) {
    localStorage.setItem("shortcuts", JSON.stringify(shortcuts));
    // Trigger a custom event to notify other tabs
    const event = new Event("shortcutsUpdated");
    window.dispatchEvent(event);
}

function createShortcut() {
    const iconURL = $("#iconURL").val();
    const url = $("#url").val();

    if (iconURL && url) {
        let existingShortcuts = JSON.parse(localStorage.getItem("shortcuts")) || [];
        let existingShortcutIndex = -1;

        // Check if a shortcut with the same icon URL exists
        for (let i = 0; i < existingShortcuts.length; i++) {
            if (existingShortcuts[i].iconURL === iconURL) {
                // Update the URL of the existing shortcut
                existingShortcuts[i].url = url;
                existingShortcutIndex = i;
                break;
            }
        }

        if (existingShortcutIndex === -1) {
            // Generate a unique identifier for the new shortcut
            const id = Date.now().toString();
            const shortcut = { id, iconURL, url };
            existingShortcuts.push(shortcut);
        }

        saveShortcuts(existingShortcuts); // Save shortcuts
        displayShortcuts(); // Update the display
    } else {
        alert("Please fill in all fields.");
    }
}


function displayShortcuts() {
    const shortcutList = $("#shortcutList");
    shortcutList.empty();
    const shortcuts = JSON.parse(localStorage.getItem("shortcuts")) || [];

    const uniqueShortcuts = {};

    shortcuts.forEach((shortcut, index) => {
        // Check if a shortcut with the same icon URL exists in uniqueShortcuts
        if (uniqueShortcuts.hasOwnProperty(shortcut.iconURL)) {
            // Update the URL of the existing shortcut
            uniqueShortcuts[shortcut.iconURL].url = shortcut.url;
        } else {
            // Add the shortcut to uniqueShortcuts
            uniqueShortcuts[shortcut.iconURL] = shortcut;
        }
    });

    // Convert uniqueShortcuts back to an array
    const updatedShortcuts = Object.values(uniqueShortcuts);

    updatedShortcuts.forEach((shortcut, index) => {
        const shortcutDiv = $("<div>")
            .addClass("shortcut")
            .attr("data-index", index) // Add data-index attribute to keep track of the position
            .attr("tabindex", "0"); // Add tabindex to make it focusable

        const a = $("<a>")
            .attr("onclick", shortcut.url) // Set the href attribute to the URL
            .attr("target", "_self") // Open links in a new tab/window
            .attr("tabindex", "0"); // Add tabindex to make it focusable

        const img = $("<img>")
            .attr("src", shortcut.iconURL)
            .attr("alt", "Shortcut Icon")
            .attr("tabindex", "0"); // Add tabindex to make it focusable

        const dot = $("<span>")
            .addClass("dot")
            .attr("tabindex", "0") // Add tabindex to make it focusable
            .click(function () {
                deleteShortcut(index);
            });

        a.append(img);
        shortcutDiv.append(a, dot);
        shortcutList.append(shortcutDiv);
    });

    // Make the shortcutList sortable
    shortcutList.sortable({
        placeholder: "sortable-placeholder", // Add a placeholder class for better UX
        start: function (event, ui) {
            // Adjust the icon's position when dragging starts
            ui.helper.find("img").css("margin-top", "-80px");

            // Hide the dot when dragging starts
            ui.helper.find(".dot").hide();
        },
        stop: function (event, ui) {
            // Reset the icon's position when dragging stops
            ui.helper.find("img").css("margin-top", "0");

            // Show the dot when dragging stops
            ui.helper.find(".dot").show();
        },
        update: function (event, ui) {
            const newIndex = ui.item.index();
            let existingShortcuts = JSON.parse(localStorage.getItem("shortcuts")) || [];
            const movedShortcut = existingShortcuts.splice(ui.item.data("index"), 1)[0];
            existingShortcuts.splice(newIndex, 0, movedShortcut);
            saveShortcuts(existingShortcuts);
        },
    });
}

function deleteShortcut(index) {
    let existingShortcuts = JSON.parse(localStorage.getItem("shortcuts")) || [];
    if (index >= 0 && index < existingShortcuts.length) {
        existingShortcuts.splice(index, 1);
        saveShortcuts(existingShortcuts);
    }
}

$(document).ready(function () {
    // Listen for the custom event "shortcutsUpdated" to update shortcuts in real-time
    window.addEventListener("shortcutsUpdated", displayShortcuts);

    // Display initial shortcuts
    displayShortcuts();

    // Listen for changes in localStorage from other tabs/windows
    window.addEventListener("storage", function (e) {
        if (e.key === "shortcuts" && e.newValue !== null) {
            // When localStorage changes, update the shortcuts list
            displayShortcuts();
openstartFunction();
        }
    });
});
