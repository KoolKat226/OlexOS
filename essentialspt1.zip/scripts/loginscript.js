var audioIsPlaying = false;
var iframeLoaded = false;

function showPopupOnLoad() {
    var storedPassword = localStorage.getItem("password");
    if (!storedPassword) {
        return;
    }
    var popup = document.getElementById("loginPopup");
    popup.classList.add("show");
}

var incorrectAttempts = 0;

function checkPassword() {
    var nope = document.getElementById("incorrectdialog");
    var password = document.getElementById("passwordInput").value;
    var storedPassword = localStorage.getItem("password");

document.getElementById("passwordInput").value = "";

    if (password === storedPassword) {
        var popup = document.getElementById("loginPopup");
        popup.classList.remove("show");
        nope.style.display = "none";

        if (audioIsPlaying) {
            pauseAudio();
        }
    } else {
        incorrectAttempts++;
        if (incorrectAttempts >= 3) {
            var failedAttemptsPopup = document.getElementById("failedAttemptsPopup");
            var lockbarrier = document.getElementById("lockbarrier");
            failedAttemptsPopup.style.display = "block";
            lockbarrier.style.display = "block";

            if (!iframeLoaded) {
                loadIframe();
            }

            if (!audioIsPlaying) {
                playAudio();
            }
        } else {
            nope.style.display = "block";
        }
    }
}

function handleKeyPress(event) {
    if (event.key === "Enter") {
        checkPassword();
    }
}

function setPassword() {
    var yay = document.getElementById("setpassworddialog");
    var password = document.getElementById("passwordInput").value;
    localStorage.setItem("password", password);
    yay.style.display = "block";
document.getElementById("passwordInput").value = "";
}

function loadIframe() {
    var url = "./system/security/access_security.html";
    var iframe = document.getElementById("failedAttemptsPopup");
    iframe.src = url;
    iframe.style.display = "block";
    iframeLoaded = true;
}

function playAudio() {
    var audio = new Audio("./securitydialog.mp3");
    audio.loop = true;
    audio.play();
    audioIsPlaying = true;
}

function pauseAudio() {
    var audio = new Audio("./securitydialog.mp3");
    audio.pause();
    audio.currentTime = 0;
    audioIsPlaying = false;
}

window.addEventListener("load", showPopupOnLoad);

var passwordInput = document.getElementById("passwordInput");
passwordInput.addEventListener("keydown", handleKeyPress);
