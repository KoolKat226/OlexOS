var gamesText = `{
    "games":[
            {
            "name":"OlexOS 2",
            "img":"./olexos2.png",
            "path":"https://olex2.everettcoleman.repl.co/.launch.html"
        },
        {
            "name":"0hh1",
            "img":"https://shadowgmes.github.io/img/0hh1.png",
            "path":"https://shadowgmes.github.io/gfiles/0hh1/"
        },
        {
            "name":"0hn0",
            "img":"https://shadowgmes.github.io/img/0hn0.png",
            "path":"https://shadowgmes.github.io/gfiles/0hn0/"
        },
        {
            "name":"2048",
            "img":"https://shadowgmes.github.io/img/2048.png",
            "path":"https://shadowgmes.github.io/gfiles/2048/"
        },
        {
            "name":"Thirty Dollar Website",
            "img":"https://shadowgmes.github.io/img/30dollarwebsite.jpg",
            "path":"https://shadowgmes.github.io/gfiles/30dollarwebsite/"
        },
        {
            "name":"Alien Hominid",
            "img":"https://shadowgmes.github.io/img/alienhominid.jpg",
            "path":"https://shadowgmes.github.io/gfiles/alienhominid/"
        },
        {
            "name":"Amidst The Sky",
            "img":"https://shadowgmes.github.io/img/amidstthesky.jpg",
            "path":"https://shadowgmes.github.io/gfiles/amidstthesky/"
        },
        {
            "name":"Among Us",
            "img":"https://shadowgmes.github.io/img/amongus.jpg",
            "path":"https://shadowgmes.github.io/gfiles/among-us/"
        },
        {
            "name":"Animator vs Animation",
            "img":"https://shadowgmes.github.io/img/animatorvsanimation.jpg",
            "path":"https://shadowgmes.github.io/gfiles/animatorvsanimation/"
        },
        {
            "name":"Asteroids",
            "img":"https://shadowgmes.github.io/img/asteroids.jpg",
            "path":"https://shadowgmes.github.io/gfiles/asteroids/"
        },
        {
            "name":"Astray",
            "img":"https://shadowgmes.github.io/img/astray.png",
            "path":"https://shadowgmes.github.io/gfiles/astray/"
        },
        {
            "name":"Ballistic Chickens",
            "img":"https://shadowgmes.github.io/img/ballistic-chickens.png",
            "path":"https://shadowgmes.github.io/gfiles/ballistic-chickens/"
        },
        {
            "name":"Basketbros.io",
            "img":"https://shadowgmes.github.io/img/basketbros.jpg",
            "path":"https://shadowgmes.github.io/gfiles/basketbros/"
        },
        {
            "name":"Bloons Tower Defense",
            "img":"https://shadowgmes.github.io/img/btd.jpg",
            "path":"https://shadowgmes.github.io/gfiles/btd/"
        },
        {
            "name":"Bloons Tower Defense 2",
            "img":"https://shadowgmes.github.io/img/btd2.jpg",
            "path":"https://shadowgmes.github.io/gfiles/btd2/"
        },
        {
            "name":"Bloons Tower Defense 3",
            "img":"https://shadowgmes.github.io/img/btd3.jpg",
            "path":"https://shadowgmes.github.io/gfiles/btd3/"
        },
        {
            "name":"Blue",
            "img":"https://shadowgmes.github.io/img/blue.png",
            "path":"https://shadowgmes.github.io/gfiles/blue/"
        },
        {
            "name":"Cat Ninja",
            "img":"https://shadowgmes.github.io/img/cat-ninja.jpg",
            "path":"https://shadowgmes.github.io/gfiles/cat-ninja/"
        },
        {
            "name":"Champion Island",
            "img":"https://shadowgmes.github.io/img/championisland.jpg",
            "path":"https://shadowgmes.github.io/gfiles/champion-island/"
        },
        {
            "name":"Chess",
            "img":"https://shadowgmes.github.io/img/chess.jpg",
            "path":"https://shadowgmes.github.io/gfiles/chess/"
        },
        {
            "name":"Chrome Dinosaur Game",
            "img":"https://shadowgmes.github.io/img/chromedino.jpg",
            "path":"https://shadowgmes.github.io/gfiles/chrome-dino/"
        },
        {
            "name":"Cookie Clicker",
            "img":"https://shadowgmes.github.io/img/cookieclicker.png",
            "path":"https://shadowgmes.github.io/gfiles/cookieclicker/"
        },
        {
            "name":"Cubefield",
            "img":"https://shadowgmes.github.io/img/cubefield.jpg",
            "path":"https://shadowgmes.github.io/gfiles/cubefield/"
        },
        {
            "name":"Custom Tetris",
            "img":"https://shadowgmes.github.io/img/customtetris.jpg",
            "path":"https://shadowgmes.github.io/gfiles/custom-tetris/"
        },
        {
            "name":"Dragon Ball Z Devolution",
            "img":"https://shadowgmes.github.io/img/dbzdevolution.jpg",
            "path":"https://shadowgmes.github.io/gfiles/dbzdevolution/"
        },
        {
            "name":"Doodle Jump",
            "img":"https://shadowgmes.github.io/img/doodlejump.png",
            "path":"https://shadowgmes.github.io/gfiles/doodle-jump/"
        },
        {
            "name":"DOOM",
            "img":"https://shadowgmes.github.io/img/doom.jpg",
            "path":"https://shadowgmes.github.io/gfiles/doom/"
        },
        {
            "name":"Drift Boss",
            "img":"https://shadowgmes.github.io/img/driftboss.png",
            "path":"https://shadowgmes.github.io/gfiles/drift-boss/"
        },
        {
            "name":"Edge Surf",
            "img":"https://shadowgmes.github.io/img/edgesurf.png",
            "path":"https://shadowgmes.github.io/gfiles/edgesurf/"
        },
        {
            "name":"Eggy Car",
            "img":"https://shadowgmes.github.io/img/eggycar.png",
            "path":"https://shadowgmes.github.io/gfiles/eggy-car/"
        },
        {
            "name":"Elastic Man",
            "img":"https://shadowgmes.github.io/img/elasticman.jpg",
            "path":"https://shadowgmes.github.io/gfiles/elastic-man/"
        },
        {
            "name":"Flag Racer",
            "img":"https://shadowgmes.github.io/img/flagracer.png",
            "path":"https://shadowgmes.github.io/gfiles/flagracer/"
        },
        {
            "name":"Flappy Bird",
            "img":"https://shadowgmes.github.io/img/flappybird.png",
            "path":"https://shadowgmes.github.io/gfiles/flappybird/"
        },
        {
            "name":"Fluid Simulation",
            "img":"https://shadowgmes.github.io/img/fluidsimulation.png",
            "path":"https://shadowgmes.github.io/gfiles/fluid-simulation/"
        },
        {
            "name":"Friday Night Funkin",
            "img":"https://shadowgmes.github.io/img/fnf.jpg",
            "path":"https://shadowgmes.github.io/gfiles/fnf-week7/"
        },
        {
            "name":"GBA Emulator",
            "img":"https://shadowgmes.github.io/img/gba.jpg",
            "path":"https://shadowgmes.github.io/gfiles/gba/"
        },
        {
            "name":"Google Snake",
            "img":"https://shadowgmes.github.io/img/gsnake.png",
            "path":"https://shadowgmes.github.io/gfiles/google-snake/"
        },
        {
            "name":"Hacker Typer",
            "img":"https://shadowgmes.github.io/img/hackertyper.png",
            "path":"https://shadowgmes.github.io/gfiles/hackertyper/"
        },
        {
            "name":"HexGL",
            "img":"https://shadowgmes.github.io/img/hexgl.png",
            "path":"https://shadowgmes.github.io/gfiles/hexgl/"
        },
        {
            "name":"Hextris",
            "img":"https://shadowgmes.github.io/img/hextris.png",
            "path":"https://shadowgmes.github.io/gfiles/hextris/"
        },
        {
            "name":"Impossible Quiz",
            "img":"https://shadowgmes.github.io/img/impossiblequiz.jpg",
            "path":"https://shadowgmes.github.io/gfiles/impossible-quiz/"
        },
        {
            "name":"Jacksmith",
            "img":"https://shadowgmes.github.io/img/jacksmith.png",
            "path":"https://shadowgmes.github.io/gfiles/jacksmith/"
        },
        {
            "name":"Madalin Stunt Cars 2",
            "img":"https://shadowgmes.github.io/img/madalincars2.jpg",
            "path":"https://shadowgmes.github.io/gfiles/madalin-cars-2/"
        },
        {
            "name":"Minecraft Classic",
            "img":"https://shadowgmes.github.io/img/classicminecraft.png",
            "path":"https://shadowgmes.github.io/gfiles/mc-classic/"
        },
        {
            "name":"Mineblocks",
            "img":"https://shadowgmes.github.io/img/mineblocks.png",
            "path":"https://shadowgmes.github.io/gfiles/mineblocks/"
        },
        {
            "name":"Microsoft Flight Simulator",
            "img":"https://shadowgmes.github.io/img/msflight.png",
            "path":"https://shadowgmes.github.io/gfiles/msflight/"
        },
        {
            "name":"Moon Lander",
            "img":"https://shadowgmes.github.io/img/moonlander.png",
            "path":"https://shadowgmes.github.io/gfiles/moonlander/"
        },
        {
            "name":"Moto X3M",
            "img":"https://shadowgmes.github.io/img/motox3m.png",
            "path":"https://shadowgmes.github.io/gfiles/motox3m/"
        },
        {
            "name":"N64 Emulator",
            "img":"https://shadowgmes.github.io/img/n64.jpg",
            "path":"https://shadowgmes.github.io/gfiles/n64/"
        },
        {
            "name":"Pac-Man",
            "img":"https://shadowgmes.github.io/img/pacman.jpg",
            "path":"https://shadowgmes.github.io/gfiles/pac-man/"
        },
        {
            "name":"Pac-Man 3D",
            "img":"https://shadowgmes.github.io/img/pacman3d.jpeg",
            "path":"https://shadowgmes.github.io/gfiles/pacman-3d/"
        },
        {
            "name":"Paper.io 2",
            "img":"https://shadowgmes.github.io/img/paperio2.png",
            "path":"https://shadowgmes.github.io/gfiles/paperio2/"
        },
        {
            "name":"PICO-8 Education",
            "img":"https://shadowgmes.github.io/img/pico-8.png",
            "path":"https://shadowgmes.github.io/gfiles/pico-8/"
        },
        {
            "name":"POOM",
            "img":"https://shadowgmes.github.io/img/poom.jpg",
            "path":"https://shadowgmes.github.io/gfiles/poom/"
        },
        {
            "name":"Powder Game",
            "img":"https://shadowgmes.github.io/img/powdergame.jpeg",
            "path":"https://shadowgmes.github.io/gfiles/powder-game/dust2.html"
        },
        {
            "name":"Retro Bowl",
            "img":"https://shadowgmes.github.io/img/retrobowl.jpg",
            "path":"https://shadowgmes.github.io/gfiles/retro-bowl/"
        },        {
            "name":"Ruffle (Flash Emulator)",
            "img":"https://shadowgmes.github.io/img/ruffle.png",
            "path":"https://shadowgmes.github.io/gfiles/ruffle-demo/"
        },
        {
            "name":"Run 2",
            "img":"https://shadowgmes.github.io/img/run2.png",
            "path":"https://shadowgmes.github.io/gfiles/run2/"
        },
        {
            "name":"Sandboxels",
            "img":"https://shadowgmes.github.io/img/sandboxels.png",
            "path":"https://shadowgmes.github.io/gfiles/sandboxels/"
        },
        {
            "name":"Sandspiel",
            "img":"https://shadowgmes.github.io/img/sandspiel.png",
            "path":"https://shadowgmes.github.io/gfiles/sandspiel/"
        },
        {
            "name":"Slope",
            "img":"https://shadowgmes.github.io/img/slope.jpg",
            "path":"https://shadowgmes.github.io/gfiles/slope/"
        },
        {
            "name":"Super Mario 64",
            "img":"https://shadowgmes.github.io/img/sm64.jpg",
            "path":"https://shadowgmes.github.io/gfiles/sm64/"
        },
        {
            "name":"Space Cadet Pinball",
            "img":"https://shadowgmes.github.io/img/spacecadetpinball.jpg",
            "path":"https://shadowgmes.github.io/gfiles/space-cadet-pinball/"
        },
        {
            "name":"Spinning Rat",
            "img":"https://shadowgmes.github.io/img/spinningrat.png",
            "path":"https://shadowgmes.github.io/gfiles/spinningrat/"
        },
        {
            "name":"Subway Surfers",
            "img":"https://shadowgmes.github.io/img/subwaysurfers.png",
            "path":"https://shadowgmes.github.io/gfiles/subway-surfers/"
        },
        {
            "name":"Super Smash Flash",
            "img":"https://shadowgmes.github.io/img/ssf.png",
            "path":"https://shadowgmes.github.io/gfiles/ssf/"
        },
        {
            "name":"Tank Trouble 2",
            "img":"https://shadowgmes.github.io/img/tanktrouble2.jpg",
            "path":"https://shadowgmes.github.io/gfiles/tank-trouble-2/"
        },
        {
            "name":"Temple Run 2",
            "img":"https://shadowgmes.github.io/img/templerun2.jpeg",
            "path":"https://shadowgmes.github.io/gfiles/temple-run-2/"
        },
        {
            "name":"Tetris",
            "img":"https://shadowgmes.github.io/img/tetris.jpg",
            "path":"https://shadowgmes.github.io/gfiles/tetris/"
        },
        {
            "name":"Tiny Fishing",
            "img":"https://shadowgmes.github.io/img/tiny-fishing.png",
            "path":"https://shadowgmes.github.io/gfiles/tinyfishing/"
        },
        {
            "name":"Toss The Turtle",
            "img":"https://shadowgmes.github.io/img/tosstheturtle.png",
            "path":"https://shadowgmes.github.io/gfiles/tosstheturtle/"
        },
        {
            "name":"Overtype Typewriter",
            "img":"https://shadowgmes.github.io/img/typewriter.jpeg",
            "path":"https://shadowgmes.github.io/gfiles/typewriter/"
        },
        {
            "name":"Very Normal Shooter",
            "img":"https://shadowgmes.github.io/img/verynormalshooter.jpg",
            "path":"https://shadowgmes.github.io/gfiles/verynormalshooter/"
        },
        {
            "name":"Vex 3",
            "img":"https://shadowgmes.github.io/img/vex-3.jpg",
            "path":"https://shadowgmes.github.io/gfiles/vex3/"
        },
        {
            "name":"Vex 4",
            "img":"https://shadowgmes.github.io/img/vex4.jpg",
            "path":"https://shadowgmes.github.io/gfiles/vex4/"
        },
        {
            "name":"Vex 5",
            "img":"https://shadowgmes.github.io/img/vex-5.jpg",
            "path":"https://shadowgmes.github.io/gfiles/vex5/"
        },
        {
            "name":"Vex 6",
            "img":"https://shadowgmes.github.io/img/vex6.jpg",
            "path":"https://shadowgmes.github.io/gfiles/vex6/"
        },
        {
            "name":"Wall Smash",
            "img":"https://shadowgmes.github.io/img/wallsmash.png",
            "path":"https://shadowgmes.github.io/gfiles/wallsmash/"
        },
        {
            "name":"Webretro",
            "img":"https://shadowgmes.github.io/img/webretro.png",
            "path":"https://shadowgmes.github.io/gfiles/webretro/"
        },
        {
            "name":"Wordle",
            "img":"https://shadowgmes.github.io/img/wordle.jpg",
            "path":"https://shadowgmes.github.io/gfiles/wordle/"
        },
        {
            "name":"World's Hardest Game",
            "img":"https://shadowgmes.github.io/img/hardestgame.jpg",
            "path":"https://shadowgmes.github.io/gfiles/worlds-hardest-game/"
        }
    ]
}`;
var gameObject = JSON.parse(gamesText);
for (i in gameObject.games) {
  let elem1 = document.createElement("div");
  elem1.className = "game-button";
  elem1.setAttribute('tabindex', "0");
  document.getElementById("gameSelect").appendChild(elem1);
  console.log("div made");
  let elem2 = document.createElement("a");
  
    elem2.href = gameObject.games[i].path;
    elem2.setAttribute('tabindex', "0");
  
  elem1.appendChild(elem2);
  console.log("a made");
  let elem3 = document.createElement("img");
  elem3.src = gameObject.games[i].img;
  elem3.setAttribute('tabindex', "0");
  elem3.alt = gameObject.games[i].name;
  elem2.appendChild(elem3);
  console.log("img made");
  let elem4 = document.createElement("p");
  elem4.innerHTML = gameObject.games[i].name;
  elem2.appendChild(elem4);
  console.log("p made");
}
