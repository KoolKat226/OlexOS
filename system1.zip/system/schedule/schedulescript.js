    let events = JSON.parse(localStorage.getItem('events')) || [];
    let selectedDate = new Date().toISOString().split('T')[0];

    function saveEvents() {
      localStorage.setItem('events', JSON.stringify(events));
    }

    function displayEventsForSelectedDay() {
      const formattedSelectedDate = selectedDate.split('-').reverse().join('-');
      const selectedEvents = events.filter(event => event.date === formattedSelectedDate);

      const selectedDayEventsContainer = document.getElementById('selectedDayEvents');
      selectedDayEventsContainer.innerHTML = '';

      if (selectedEvents.length === 0) {
        const noEventsText = document.createElement('a');
        noEventsText.classList.add('noeventstext');
        noEventsText.innerText = 'No Upcoming Events...';
        selectedDayEventsContainer.appendChild(noEventsText);
      } else {
        selectedEvents.forEach(event => {
          const eventElement = createEventElement(event);
          selectedDayEventsContainer.appendChild(eventElement);
        });
      }
    }

    function displayAllEvents() {
      const allEventsContainer = document.getElementById('allEvents');
      allEventsContainer.innerHTML = '';

      if (events.length === 0) {
        const noEventsText = document.createElement('a');
        noEventsText.classList.add('noeventstext2');
        noEventsText.innerText = 'No Events Yet!';
        allEventsContainer.appendChild(noEventsText);
      } else {
        events.sort((a, b) => {
          const dateTimeA = new Date(`${a.date}T${a.time}`);
          const dateTimeB = new Date(`${b.date}T${b.time}`);
          return dateTimeA - dateTimeB;
        });

        events.forEach(event => {
          const eventElement = createEventElement(event);
          allEventsContainer.appendChild(eventElement);
        });
      }
    }

    function createEventElement(event) {
      const eventElement = document.createElement('div');
      eventElement.classList.add('event');
      eventElement.innerHTML = `
        <div class="title">${event.title}</div>
        ${event.notes ? `<div class="notes">${formatNotes(event.notes)}</div>` : ''}
        <div class="datetime">
          <span>${event.date}</span>
          <span>${formatTime(event.time)}</span>
        </div>
        <button class="deleteevent">✔ Done</button>
      `;

      const deleteButton = eventElement.querySelector('.deleteevent');
      deleteButton.addEventListener('click', () => {
        deleteEvent(event);
      });

      return eventElement;
    }

    function formatTime(time) {
      const [hours, minutes] = time.split(':');
      const parsedHours = parseInt(hours, 10);
      const suffix = parsedHours >= 12 ? 'PM' : 'AM';
      const formattedHours = parsedHours % 12 || 12;

      return `${formattedHours}:${minutes} ${suffix}`;
    }

    function formatNotes(notes) {
      const urlRegex = /(https?:\/\/[^\s]+)/g;
      return notes.replace(urlRegex, '<a href="$1" target="_blank">$1</a>');
    }

    function addEvent(title, notes, date, time) {
      const event = {
        title,
        notes,
        date: date.split('-').reverse().join('-'), // Convert date to format "DD-MM-YYYY"
        time,
      };

      events.push(event);
      saveEvents();
      displayAllEvents();
      displayEventsForSelectedDay();
    }

    function deleteEvent(event) {
      const index = events.indexOf(event);
      if (index > -1) {
        events.splice(index, 1);
        saveEvents();
        displayAllEvents();
        displayEventsForSelectedDay();
      }
    }

    const eventForm = document.getElementById('eventForm');
    eventForm.addEventListener('submit', event => {
      event.preventDefault();
      const titleInput = document.getElementById('titleInput');
      const notesInput = document.getElementById('notesInput');
      const dateInput = document.getElementById('dateInput');
      const timeInput = document.getElementById('timeInput');

      const title = titleInput.value;
      const notes = notesInput.value;
      const date = dateInput.value;
      const time = timeInput.value;

      addEvent(title, notes, date, time);

      titleInput.value = '';
      notesInput.value = '';
      dateInput.value = '';
      timeInput.value = '';
    });

    function updateSelectedDate(date) {
      selectedDate = date;
      displayEventsForSelectedDay();
    }

    const currentDate = new Date().toISOString().split('T')[0];

    displayAllEvents();
    displayEventsForSelectedDay();

    function checkForChanges(event) {
      if (event.key === 'events') {
        events = JSON.parse(event.newValue) || [];
        displayAllEvents();
        displayEventsForSelectedDay();
      }
    }

    window.addEventListener('storage', checkForChanges);