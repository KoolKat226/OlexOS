// Function to show the login popup if password is set in local storage
function showPopupOnLoad() {
    var storedPassword = localStorage.getItem("password");

    if (!storedPassword) {
        return; // No password set, so no need to show the popup
    }

    var popup = document.getElementById("loginPopup");
    popup.classList.add("show");
}

// Function to check the entered password
function checkPassword() {
    var password = document.getElementById("passwordInput").value;
    var storedPassword = localStorage.getItem("password");

    if (password === storedPassword) {
        var popup = document.getElementById("loginPopup");
        popup.classList.remove("show");
    } else {
        alert("Incorrect password. Please try again.");
    }
}

// Function to handle keydown events on the password input field
function handleKeyPress(event) {
    if (event.key === "Enter") {
        checkPassword();
    }
}

// Show the popup when the page loads
window.addEventListener("load", showPopupOnLoad);

// Add event listener for keydown events on the password input field
var passwordInput = document.getElementById("passwordInput");
passwordInput.addEventListener("keydown", handleKeyPress);


// Function to set the password in local storage
function setPassword() {
    var password = document.getElementById("passwordInput").value;
    localStorage.setItem("password", password);
    alert("Password set successfully!");
}
