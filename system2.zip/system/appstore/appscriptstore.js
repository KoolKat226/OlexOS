var button2 = document.getElementById("button2"); 
var link2Name = document.getElementById("formattedCodeInput"); 
var link2Url = document.getElementById("downloadInput"); 
var link2Target = document.getElementById("link2-target");
var display2 = document.getElementById("display2"); 



button2.addEventListener('click', () => {
	let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
	if(locallinks2 === null){
		links2 = []
	} else {
		links2 = locallinks2; 
	}
	
	links2.push("<a "+ link2Url.value + " target="+ link2Target.value + ">"+link2Name.value+"</a>"); 
	localStorage.setItem('locallink2', JSON.stringify(links2)) 
	
	showlink2()
	
	link2Url.value = ""; 
	link2Name.value = "";
}); 

const showlink2 = () => {
	let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
	if(locallinks2 === null){
		links2 = []
	} else {
		links2 = locallinks2; 
	}
	
	let link2 = ''; 
	links2.forEach((data, index) => {
		link2 += `<button class="link2">${data}</button><button class="delete" onClick="deletelink2(${index})">×</button>‏‏‎‎`
	});
	
	display2.innerHTML = link2; 
}

const deletelink2 = (index) => {
	let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
	links2.splice(index, 1);
	localStorage.setItem('locallink2', JSON.stringify(links2)); 
	showlink2();
}

showlink2()