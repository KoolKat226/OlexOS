document.addEventListener("DOMContentLoaded", function() {
  var appList = document.getElementById("app-list");
  var appIframe = document.getElementById("app-iframe");
  var popup = document.getElementById("popup");
  var popupText = document.getElementById("popup-text");
  var popupButton = document.getElementById("popup-button");
  var button2 = document.getElementById("button2");

  // Create the list of widgets
  appLinks.forEach(function(widget) {
    var listItem = document.createElement("li");
    listItem.classList.add("widget-item");

    // Create the preview image
    var image = document.createElement("img");
    image.src = widget.image;
    image.alt = widget.name + " Preview";
    image.classList.add("widget-preview");
    listItem.appendChild(image);

    // Create the widget button
    var button = document.createElement("button");
    button.textContent = widget.name;
    button.classList.add("widget-button");
    listItem.appendChild(button);

    appList.appendChild(listItem);

    // Handle button click event
    button.addEventListener("click", function() {
      showPopup("Widget Added! Refresh your Widgets to play");
      // Save the widget link in localStorage
      localStorage.setItem("widgetLink", widget.link);

      // Display the iframe with the widget link
      appIframe.src = widget.link;
      appIframe.style.display = "block";
    });
  });

  // Handle button2 click event
  button2.addEventListener("click", function() {
    showPopup("App successfully installed!");
  });

  // Close the popup when the OK button is clicked
  popupButton.addEventListener("click", function() {
    hidePopup();
  });

  // Check if a widget link is stored in localStorage and display the iframe if present
  var storedLink = localStorage.getItem("widgetLink");
  if (storedLink) {
    appIframe.src = storedLink;
    appIframe.style.display = "block";
  }

  // Function to display the popup with a given message
  function showPopup(message) {
    popupText.textContent = message;
    popup.style.display = "block";

    // Apply slide-up animation for the popup
    popup.style.transform = "translate(-50%, 100%)";
    popup.style.transition = "transform 0.3s";

    // Trigger reflow to apply initial styles before animating
    popup.offsetHeight;

    popup.style.transform = "translate(-50%, 0)"; // Slide up to the original position
  }

  // Function to close the popup with scaling-down animation
  function hidePopup() {
    // Apply scale-down animation for the popup
    popup.style.transform = "translate(-50%, 0) scale(1)";
    popup.style.transition = "transform 0.3s";

    // Trigger reflow to apply initial styles before animating
    popup.offsetHeight;

    popup.style.transform = "translate(-50%, 100%) scale(0)"; // Scale down and slide out
  }
});
