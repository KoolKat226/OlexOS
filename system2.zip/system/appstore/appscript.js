var button = document.getElementById("button"); 
var linkName = document.getElementById("link-name"); 
var linkUrl = document.getElementById("link"); 
var linkTarget = document.getElementById("link-target");
var display = document.getElementById("display"); 



button.addEventListener('click', () => {
	let localLinks = JSON.parse(localStorage.getItem('localLink'));
	if(localLinks === null){
		links = []
	} else {
		links = localLinks; 
	}
	
	links.push("<a "+ linkUrl.value + " target="+ linkTarget.value + ">"+linkName.value+"</a>"); 
	localStorage.setItem('localLink', JSON.stringify(links)) 
	
	showLink()
	
	linkUrl.value = ""; 
	linkName.value = "";
}); 

const showLink = () => {
	let localLinks = JSON.parse(localStorage.getItem('localLink'));
	if(localLinks === null){
		links = []
	} else {
		links = localLinks; 
	}
	
	let link = ''; 
	links.forEach((data, index) => {
		link += `<button class="link">${data}</button><button class="delete" onClick="deleteLink(${index})">×</button>‏‏‎‎`
	});
	
	display.innerHTML = link; 
}

const deleteLink = (index) => {
	let localLinks = JSON.parse(localStorage.getItem('localLink'));
	links.splice(index, 1);
	localStorage.setItem('localLink', JSON.stringify(links)); 
	showLink();
}

showLink()