// Define createShortcut in the global scope
function createShortcut() {
    const iconURL = $("#iconURL").val();
    const url = $("#url").val();

    if (iconURL && url) {
        const shortcut = { iconURL, url };
        const existingShortcuts = JSON.parse(localStorage.getItem("shortcuts")) || [];
        existingShortcuts.push(shortcut);
        localStorage.setItem("shortcuts", JSON.stringify(existingShortcuts));
    } else {
        alert("Please fill in all fields.");
    }
}

$(document).ready(function () {
    function displayShortcuts() {
        const shortcutList = $("#shortcutList");
        shortcutList.empty();
        const shortcuts = JSON.parse(localStorage.getItem("shortcuts")) || [];

        shortcuts.forEach((shortcut, index) => {
            const shortcutDiv = $("<div>")
                .addClass("shortcut")
                .attr("data-index", index); // Add data-index attribute to keep track of the position

            const a = $("<a>")
                .attr("onclick", shortcut.url)
                .attr("target", "_self");

            const img = $("<img>")
                .attr("src", shortcut.iconURL)
                .attr("alt", "Shortcut Icon");

            const dot = $("<span>")
                .addClass("dot")
                .click(function () {
                    deleteShortcut(index);
                });

            a.append(img);
            shortcutDiv.append(a, dot);
            shortcutList.append(shortcutDiv);
        });

        // Make the shortcutList sortable
        shortcutList.sortable({
            placeholder: "sortable-placeholder", // Add a placeholder class for better UX
            update: function (event, ui) {
                const newIndex = ui.item.index();
                const existingShortcuts = JSON.parse(localStorage.getItem("shortcuts")) || [];
                const movedShortcut = existingShortcuts.splice(ui.item.data("index"), 1)[0];
                existingShortcuts.splice(newIndex, 0, movedShortcut);
                localStorage.setItem("shortcuts", JSON.stringify(existingShortcuts));
                displayShortcuts();
            },
        });
    }

    function deleteShortcut(index) {
        const existingShortcuts = JSON.parse(localStorage.getItem("shortcuts")) || [];
        if (index >= 0 && index < existingShortcuts.length) {
            existingShortcuts.splice(index, 1);
            localStorage.setItem("shortcuts", JSON.stringify(existingShortcuts));
            displayShortcuts();
        }
    }

    displayShortcuts();
});
