var button2 = document.getElementById("button2");
var link2Name = document.getElementById("link2-name");
var link2Url = document.getElementById("link2");
var link2Target = document.getElementById("link2-target");
var display2 = document.getElementById("display2");

var button3 = document.getElementById("button3");
var link3Name = document.getElementById("link3-name");
var link3Url = document.getElementById("link3");
var link3Target = document.getElementById("link3-target");
var display3 = document.getElementById("display3");

var button4 = document.getElementById("button4");
var link4Name = document.getElementById("link4-name");
var link4Url = document.getElementById("link4");
var link4Target = document.getElementById("link4-target");
var display4 = document.getElementById("display4");

var button5 = document.getElementById("button5");
var link5Name = document.getElementById("link5-name");
var link5Url = document.getElementById("link5");
var link5Target = document.getElementById("link5-target");
var display5 = document.getElementById("display5");

window.addEventListener('load', () => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks2 === null) {
    links2 = [];
  } else {
    links2 = locallinks2;
  }
  
  links2.push("<a "+ link2Url.value + " target="+ link2Target.value + ">"+link2Name.value+"</a>");
  localStorage.setItem('locallink2', JSON.stringify(links2));
  
  let locallinks3 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks3 === null) {
    links3 = [];
  } else {
    links3 = locallinks3;
  }
  
  links3.push("<a "+ link3Url.value + " target="+ link3Target.value + ">"+link3Name.value+"</a>");
  localStorage.setItem('locallink2', JSON.stringify(links3));
  
  let locallinks4 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks4 === null) {
    links4 = [];
  } else {
    links4 = locallinks4;
  }
  
  links4.push("<a "+ link4Url.value + " target="+ link4Target.value + ">"+link4Name.value+"</a>");
  localStorage.setItem('locallink2', JSON.stringify(links4));
  
  let locallinks5 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks5 === null) {
    links5 = [];
  } else {
    links5 = locallinks5;
  }
  
  links5.push("<a "+ link5Url.value + " target="+ link5Target.value + ">"+link5Name.value+"</a>");
  localStorage.setItem('locallink2', JSON.stringify(links5));
  
  showlink2();
  showlink3();
  showlink4();
  showlink5();
  
  link2Url.value = "";
  link2Name.value = "";
  link3Url.value = "";
  link3Name.value = "";
  link4Url.value = "";
  link4Name.value = "";
  link5Url.value = "";
  link5Name.value = "";
});

const showlink2 = () => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks2 === null) {
    links2 = [];
  } else {
    links2 = locallinks2;
  }
  
  let link2 = '';
  links2.forEach((data, index) => {
    link2 += `<button class="link2">${data}</button><button class="delete" onClick="deletelink2(${index})">×</button>‏‏‎‎`;
  });
  
  display2.innerHTML = link2;
};

const showlink3 = () => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks2 === null) {
    links3 = [];
  } else {
    links3 = locallinks2;
  }
  
  let link3 = '';
  links3.forEach((data, index) => {
    link3 += `<button class="link3">${data}</button><button class="delete" onClick="deletelink3(${index})">×</button>‏‏‎‎`;
  });
  
  display3.innerHTML = link3;
};

const showlink4 = () => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks2 === null) {
    links4 = [];
  } else {
    links4 = locallinks2;
  }
  
  let link4 = '';
  links4.forEach((data, index) => {
    link4 += `<button class="link4">${data}</button><button class="delete" onClick="deletelink4(${index})">×</button>‏‏‎‎`;
  });
  
  display4.innerHTML = link4;
};

const showlink5 = () => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  if (locallinks2 === null) {
    links5 = [];
  } else {
    links5 = locallinks2;
  }
  
  let link5 = '';
  links5.forEach((data, index) => {
    link5 += `<button class="link5">${data}</button><button class="delete" onClick="deletelink5(${index})">×</button>‏‏‎‎`;
  });
  
  display5.innerHTML = link5;
};

const deletelink2 = (index) => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  links2.splice(index, 1);
  localStorage.setItem('locallink2', JSON.stringify(links2));
  showlink2();
};

const deletelink3 = (index) => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  links3.splice(index, 1);
  localStorage.setItem('locallink2', JSON.stringify(links3));
  showlink3();
};

const deletelink4 = (index) => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  links4.splice(index, 1);
  localStorage.setItem('locallink2', JSON.stringify(links4));
  showlink4();
};

const deletelink5 = (index) => {
  let locallinks2 = JSON.parse(localStorage.getItem('locallink2'));
  links5.splice(index, 1);
  localStorage.setItem('locallink2', JSON.stringify(links5));
  showlink5();
};

showlink2();
showlink3();
showlink4();
showlink5();
