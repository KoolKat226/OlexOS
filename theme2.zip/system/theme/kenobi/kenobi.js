function changeBackgroundColorsAndImages() {
  var elements1 = document.querySelectorAll('[style*="background: rgb(0, 11, 19)"]');
  var elements2 = document.querySelectorAll('[style*="background: rgba(30, 25, 27, 0.8)"]');
  var elements3 = document.querySelectorAll('[style*="background: rgb(107, 107, 107)"]');
  var elements5 = document.querySelectorAll('[style*="background: rgb(22, 22, 22)"]');
  var elements6 = document.querySelectorAll('[src*="./startup.mp3"]');
  var images = document.querySelectorAll('img[src="./images/logo.png"]');
  var olexosLogo = document.getElementById('olexoslogo');


  elements1.forEach(function(element) {
  });

  elements2.forEach(function(element) {
    element.style.background = 'rgba(28, 23, 15, 0.8)';
  });

  elements3.forEach(function(element) {
    element.style.background = '#f4f6f5';
  });

  elements5.forEach(function(element) {
    element.style.background = '#f4f6f5';
  });

  elements6.forEach(function(element) {
    element.src = './system/theme/kenobi/kenobi.mp3';
  });

  images.forEach(function(image) {
    image.src = './system/theme/kenobi/kenobilogo.gif';
  });

  if (olexosLogo) {
    olexosLogo.src = './system/theme/kenobi/kenobilogo.gif';
  }
}

    function changeFontToStarWars() {
      var fontUrl = "./system/theme/kenobi/starwars.otf";
      var style = document.createElement("style");
      style.innerHTML = `
        @font-face {
          font-family: "StarWarsFont";
          src: url(${fontUrl}) format("opentype");
        }
        body, h1, h2, h3, h4, h5, h6, h8, a, small, span, td, th {
          font-family: "StarWarsFont" !important;
        }
      `;
      document.head.appendChild(style);
    }

    // Call the function to change the font on this webpage
    changeFontToStarWars();

    function themedarkmode() {
      var isDarkmodeEnabled = localStorage.getItem("isDarkmodeEnabled");
      if (isDarkmodeEnabled === "false") {
        localStorage.setItem("isDarkmodeEnabled", "true");
        window.open('./olex.html','_self');
      }
    }

window.open('./system/theme/kenobi/kenobi.html','theme');
changeBackgroundColorsAndImages();
themedarkmode();


var style = document.createElement("style");
document.body.appendChild(style);
  style.innerHTML = `
.link2 {
font-family: 'Montserrat', sans-serif;
	margin-top: 5px;
	margin-right: 2px;
	border-radius: 20px;
	padding: 7px;
	border: dotted 1px #BCB07F; 
      width:100px;
      height:80px;
  overflow: scroll; /* enable scrolling */
  scrollbar-width: none; /* hide scrollbar for Firefox */
  -ms-overflow-style: none; /* hide scrollbar for IE and Edge */
transition: box-shadow .3s;
transition: 0.3s;
  display: inline-block;
cursor: default;
}

    #loading-screen {
background-image: url("./system/theme/spidey/spideybg.jpg");
    }
`;
  document.body.appendChild(style);
