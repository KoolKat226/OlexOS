// app-links.js
var appLinks = [
    { 
        name: "+ Add",
        link: "../clipboard/clipboarddata/clipwidget.html",
        image: "../../images/clipboardwidgetpreview.png"
    },
    { 
        name: "+ Add",
        link: "../browser/dinowidget.html",
        image: "../../images/dinowidgetpreview.png"
    },
    { 
        name: "+ Add",
        link: "../music/widget.html",
        image: "../../images/musicwidgetpreview.png"
    },
];
