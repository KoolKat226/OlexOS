var appLinks = [
    { 
        name: "+ Set",
        type: "audio",
        link: "../wallpaper/blank.html",
        image: "",
        audio: ""
    },
    { 
        name: "+ Set Default",
        type: "audio",
        link: "../wallpaper/index.html",
        image: "./image/defaultbanner.png",
        audio: ""
    },
    { 
        name: "+ Set Clutter",
        type: "audio",
        link: "../wallpaper/introwall.html",
        image: "./image/clutterbanner.png",
        audio: "./system/theme/audio/olex.mp3"
    },
    { 
        name: "+ Set Cereal",
        type: "audio",
        link: "../wallpaper/cereal.html",
        image: "./image/cerealbanner.png",
        audio: "./system/theme/audio/cereal.mp3"
    },
    { 
        name: "+ Set Forest",
        type: "audio",
        link: "../wallpaper/forest.html",
        image: "./image/forestbanner.png",
        audio: "./system/theme/audio/forest.mp3"
    },
    { 
        name: "+ Set Island",
        type: "audio",
        link: "../wallpaper/island.html",
        image: "./image/islandbanner.png",
        audio: "./system/theme/audio/dock.mp3"
    },
    { 
        name: "+ Set Nice Rocks",
        type: "audio",
        link: "../wallpaper/nicerocks.html",
        image: "./image/nicerocksbanner.png",
        audio: "./system/theme/audio/beach.mp3"
    },
];
