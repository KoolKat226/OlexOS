var apps = [
  {
    name: "Default",
    description: "Offered by OlexOS",
    link: "../wallpaper/index.html",
    icon: "https://open.jacsyn.repl.co/theme/default/.icon.png"
  },
  {
    name: "Olex Collection",
    description: "Offered by OlexOS",
    link: "https://open.jacsyn.repl.co/theme/default/.wallpaper.html",
    icon: "https://open.jacsyn.repl.co/theme/default/.icon.png"
  },
  {
    name: "Yummy Cereal",
    description: "Offered by OlexOS",
    link: "https://open.jacsyn.repl.co/theme/cereal/.wallpaper.html",
    icon: "https://open.jacsyn.repl.co/theme/cereal/.icon.png"
  },
  {
    name: "Kimitsu Forest",
    description: "Offered by OlexOS",
    link: "https://open.jacsyn.repl.co/theme/forest/.wallpaper.html",
    icon: "https://open.jacsyn.repl.co/theme/forest/.icon.png"
  },
  {
    name: "Sunset Dock",
    description: "Offered by OlexOS",
    link: "https://open.jacsyn.repl.co/theme/dock/.wallpaper.html",
    icon: "https://open.jacsyn.repl.co/theme/dock/.icon.png"
  },
  {
    name: "Motukieki Beach",
    description: "Offered by OlexOS",
    link: "https://open.jacsyn.repl.co/theme/beach/.wallpaper.html",
    icon: "https://open.jacsyn.repl.co/theme/beach/.icon.png"
  },
  {
    name: "Jurrasic World",
    description: "Offered by OlexOS",
    link: "https://open.jacsyn.repl.co/theme/jurrasicworld/.wallpaper.html",
    icon: "https://open.jacsyn.repl.co/theme/jurrasicworld/.icon.png"
  },
  {
    name: "Pirates of the Carribean",
    description: "Offered by OlexOS",
    link: "https://open.jacsyn.repl.co/theme/pirates/.wallpaper.html",
    icon: "https://open.jacsyn.repl.co/theme/pirates/.icon.png"
  },

];
