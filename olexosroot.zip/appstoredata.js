var apps = [
  {
    name: "Browser",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/browsericon.png`;document.getElementById(`iframeURLInput`).value =`./system/browser/index.html`;createIframe();",
    icon: "./images/browsericon.png"
  },
  {
    name: "My Schedule",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/scheduleicon.png`;document.getElementById(`iframeURLInput`).value =`./system/schedule/index.html`;createFullscreenIframe();",
    icon: "./images/scheduleicon.png"
  },
  {
    name: "Music",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/music.png`;document.getElementById(`iframeURLInput`).value =`./system/music/index.html`;createIframe();",
    icon: "./images/music.png"
  },
  {
    name: "Clipboard",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/clipboard.png`;document.getElementById(`iframeURLInput`).value =`./system/clipboard/index.html`;createIframe();",
    icon: "./images/clipboard.png"
  },
  {
    name: "Calculator",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/calculatoricon.png`;document.getElementById(`iframeURLInput`).value =`https://calculator.apps.chrome/`;createIframe();",
    icon: "./images/calculatoricon.png"
  },
  {
    name: "Habit Tracker",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/habittrackicon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.habittracker.html`;createIframe();",
    icon: "./images/habittrackicon.png"
  },
  {
    name: "App Labs",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/applabsicon.png`;document.getElementById(`iframeURLInput`).value =`./system/applabs/index.html`;createFullscreenIframe();",
    icon: "./images/applabsicon.png"
  },
  {
    name: "My Games",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/gamebubble.png`;document.getElementById(`iframeURLInput`).value =`https://olex.jacsyn.repl.co/cantaloupe/index.html`;createFullscreenIframe();",
    icon: "./images/gamebubble.png"
  },
  {
    name: "Appstore",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/appstorefavicon.png`;document.getElementById(`iframeURLInput`).value =`./system/appstore/appstore.html`;createIframe();",
    icon: "./images/appstorefavicon.png"
  },
  {
    name: "Wikepedia",
    developer: "Offered by Wikimedia",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://www.wikipedia.org/portal/wikipedia.org/assets/img/Wikipedia-logo-v2@1.5x.png`;document.getElementById(`iframeURLInput`).value =`https://wikepedia.org`;createIframe();",
    icon: "https://www.wikipedia.org/portal/wikipedia.org/assets/img/Wikipedia-logo-v2@1.5x.png"
  },
  {
    name: "Firefox",
    developer: "Offered by Mozilla",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =``;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.firefox.html`;createIframe();",
    icon: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Firefox_logo%2C_2019.svg/1200px-Firefox_logo%2C_2019.svg.png"
  },
  {
    name: "Youtube",
    developer: "Offered by invidious",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://static.vecteezy.com/system/resources/previews/018/930/572/original/youtube-logo-youtube-icon-transparent-free-png.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.youtube.html`;createIframe();",
    icon: "https://static.vecteezy.com/system/resources/previews/018/930/572/original/youtube-logo-youtube-icon-transparent-free-png.png"
  },
  {
    name: "Galaga",
    developer: "Offered by Namco",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/galaga.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.galaga.html`;createIframe();",
    icon: "./images/galaga.gif"
  },
  {
    name: "Glorious Purpose",
    developer: "Offered by OlexOS",
    code: "document.getElementById(&quot;scriptInput&quot;).value =&quot;javascript:var OlexOSGOBETA=`1.0`;var s = document.createElement(`script`);s.type=`text/javascript`;document.body.appendChild(s);s.src=`./system/theme/loki/loki.js`;void(0);&quot;;setScript();",
    icon: "./images/lokiicon.png"
  },
  {
    name: "Hello There",
    developer: "Offered by OlexOS",
    code: "document.getElementById(&quot;scriptInput&quot;).value =&quot;javascript:var OlexOSGOBETA=`1.0`;var s = document.createElement(`script`);s.type=`text/javascript`;document.body.appendChild(s);s.src=`./system/theme/kenobi/kenobi.js`;void(0);&quot;;setScript();",
    icon: "./images/kenobiicon.png"
  },
  {
    name: "Spidermanify",
    developer: "Offered by OlexOS",
    code: "document.getElementById(&quot;scriptInput&quot;).value =&quot;javascript:var OlexOSGOBETA=`1.0`;var s = document.createElement(`script`);s.type=`text/javascript`;document.body.appendChild(s);s.src=`./system/theme/spidey/spidey.js`;void(0);&quot;;setScript();",
    icon: "./images/spideyicon.png"
  },
  {
    name: "Bobs School",
    developer: "Offered by Bob",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://cdn-icons-png.flaticon.com/512/4720/4720451.png`;document.getElementById(`iframeURLInput`).value =`https://schooltest62.w3spaces.com/index.html`;createIframe();",
    icon: "https://cdn-icons-png.flaticon.com/512/4720/4720451.png"
  },
  {
    name: "Cube",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/cube/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.cube.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/cube/.icon.png"
  },
  {
    name: "Corbin the Game",
    developer: "Offered by Corbin",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/corbin/corbinthegame.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.corbin.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/corbin/corbinthegame.png"
  },
  {
    name: "Guilded",
    developer: "Offered by Guilded.gg",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/guilded/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.guilded.html`;createIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/guilded/.icon.png"
  },
  {
    name: "Doodle Jump",
    developer: "Offered by OlexOS",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/doodlejump/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.doodlejump.html`;createIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/doodlejump/.icon.png"
  },
  {
    name: "Minecraft",
    developer: "Offered by Mojang",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/minecraft/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.minecraft.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/minecraft/.icon.png"
  },
  {
    name: "RetroArch Emulator",
    developer: "Offered by RetroArch",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/retroemu/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.retroemu.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/retroemu/.icon.png"
  },
  {
    name: "Ghost Chat Bot",
    developer: "Offered by Dusan Halicky",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/ghostchatbot/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.ghostchatbot.html`;createIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/ghostchatbot/.icon.png"
  },
  {
    name: "Happy Friday",
    developer: "Offered by SmashPlug",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/happyfriday/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.happyfriday.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/happyfriday/.icon.png"
  },
  {
    name: "Sandboxels",
    developer: "Offered by R74n",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`./images/gamebubble.png`;document.getElementById(`iframeURLInput`).value =`https://shadowgmes.github.io/gfiles/sandboxels`;createFullscreenIframe();",
    icon: "https://sandboxels.r74n.com/icons/icon.png"
  },
  {
    name: "Subway Surfers",
    developer: "Offered by Sybo Games",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/subwaysurfers/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.subwaysurfers.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/subwaysurfers/.icon.png"
  },
  {
    name: "Super Mario 64",
    developer: "Offered by Nintendo",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/mario64/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.mario64.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/mario64/.icon.png"
  },
  {
    name: "Mario Kart 64",
    developer: "Offered by Nintendo",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/64emu/kart64.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.kart64.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/64emu/kart64.png"
  },
  {
    name: "Retro Bowl",
    developer: "Offered by New Star Games",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/retrobowl/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.retrobowl.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/retrobowl/.icon.png"
  },
  {
    name: "Spelunky",
    developer: "Offered by MossMouth",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/spelunky/spelunkyopen.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.spelunky.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/spelunky/src/.icon.png"
  },
  {
    name: "Shell Shockers",
    developer: "Offered by Blue Wizard",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/bluewizard/shellshock.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/bluewizard/shellshock.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/bluewizard/shellshock.png"
  },
  {
    name: "Bad Egg",
    developer: "Offered by Blue Wizard",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/bluewizard/badegg.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/bluewizard/badegg.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/bluewizard/badegg.png"
  },
  {
    name: "Funny Shooter 2",
    developer: "Offered by Graham Finholtd",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://thirdpartyapp.jacsyn.repl.co/game/funnyshooter2/.icon.png`;document.getElementById(`iframeURLInput`).value =`https://thirdpartyapp.jacsyn.repl.co/.funnyshooter2.html`;createFullscreenIframe();",
    icon: "https://thirdpartyapp.jacsyn.repl.co/game/funnyshooter2/.icon.png"
  },
  {
    name: "A Small World Cup",
    developer: "Offered by Everett Coleman",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://i.ytimg.com/vi/2LXQMs5DZ1k/hqdefault.jpg`;document.getElementById(`iframeURLInput`).value =`https://asmallworldcup.com/`;createFullscreenIframe();",
    icon: "https://i.ytimg.com/vi/2LXQMs5DZ1k/hqdefault.jpg"
  },
  {
    name: "Modern Castle Wars",
    developer: "Offered by Everett Coleman",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://images.twoplayergames.org/files/games/o1/Castel_Wars_Modern/Castel_Wars_Modern.jpg?auto=format&w=200`;document.getElementById(`iframeURLInput`).value =`https://images-opensocial.googleusercontent.com/gadgets/ifr?url=https://174902643-184720473821057493.preview.editmysite.com/uploads/b/139890129-355621516266853465/files/cwm.xml`;createFullscreenIframe();",
    icon: "https://images.twoplayergames.org/files/games/o1/Castel_Wars_Modern/Castel_Wars_Modern.jpg"
  },
  {
    name: "VEX 7",
    developer: "Offered by Everett Coleman",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://img.gamedistribution.com/0c454c9562d249d28ba3a2b50564042c-512x512.jpg`;document.getElementById(`iframeURLInput`).value =`https://vexunblocked.github.io/7/`;createFullscreenIframe();",
    icon: "https://img.gamedistribution.com/0c454c9562d249d28ba3a2b50564042c-512x512.jpg"
  },
  {
    name: "Pixel Shooter",
    developer: "Offered by Everett Coleman",
    code: "document.getElementById(`iframeNameInput`).value =`somethingfunny`;document.getElementById(`iframeIconInput`).value =`https://play-lh.googleusercontent.com/KLguJHl0OpfXaYm5oA0qZyT_oLvk5x5mzd0b3cxF0MhGVSHnxEaljGLkKrPTqtSnLg=w240-h480-rw`;document.getElementById(`iframeURLInput`).value =`https://images-opensocial.googleusercontent.com/gadgets/ifr?url=https://274019683-173520394482650759.preview.editmysite.com/uploads/b/139890129-131715539788281629/files/ps.xml`;createFullscreenIframe();",
    icon: "https://play-lh.googleusercontent.com/KLguJHl0OpfXaYm5oA0qZyT_oLvk5x5mzd0b3cxF0MhGVSHnxEaljGLkKrPTqtSnLg=w240-h480-rw"
  },

];
