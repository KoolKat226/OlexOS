// Retrieve DOM elements
const chatDisplay = document.getElementById('chat-display');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

// Event listener for send button
sendButton.addEventListener('click', sendMessage);

// Event listener for user pressing Enter key
userInput.addEventListener('keyup', function(event) {
  if (event.keyCode === 13) {
    sendMessage();
  }
});

// Object to store the included input text and corresponding generated responses
const responses = {
  'Hello There': [
    'General Kenobi...'
  ],
     'please': [
    'Your so kind for saying please :)',
      'Gladly!'
  ],
  'hi olex': [
    'Hey Buddy!'
  ],
  'Hello': [
    'Hello There'
  ],
  'are you a fish': [
    'Yep, im 99.9% fish'
  ],
    'who made you': [
    'A very handsome man named Jackson Coleman'
  ],
      'who created you': [
    'A very handsome man named Jackson Coleman'
  ],
        'who is your creator': [
    'A very handsome man named Jackson Coleman'
  ],
  'whats the .1%?': [
    'Green Beans'
  ],
  'whats the .1%': [
    'Green Beans'
  ],
  'what is the .1%': [
    'Green Beans'
  ],
  'what is the .1': [
    'Green Beans'
  ],
  'what is the .1%?': [
    'Green Beans'
  ],
  'whats the .1?': [
    'Green Beans'
  ],
  'what is the .1?': [
    'Green Beans'
  ],
  "what's the .1?": [
    'Green Beans'
  ],
  "what's the .1%?": [
    'Green Beans'
  ],
  'Meaning of life': [
    '42'
  ],
  'what is his name': [
    'Gerald'
  ],
  'what is her name': [
    'Gerald'
  ],
  'whats her name': [
    'Gerald'
  ],
  'whats his name': [
    'Gerald'
  ],
  "what's his name": [
    'Gerald'
  ],
  "what's her name": [
    'Gerald'
  ],
      'everybody knows you': [
    "Really? That's cool",
    'I am flabbergasted!'
  ],
      'open app name': [
    'Your funny',
    'Your difficult...'
  ],
    'how often': [
    "All the time!",
    'Sometimes when i am bored'
  ],
    'tell me a joke': [
    "why did the chicken cross the road?",
    'No'
  ],
    'is he cool': [
    "Hell yeah he's cool",
    'All the time...'
  ],
    'is she cool': [
    "Hell yeah she's cool",
    'All the time...'
  ],
    "Hell yeah he's cool": [
    "I'm Mary Poppins Y'All!"
  ],
    "Hell yeah hes cool": [
    "I'm Mary Poppins Y'All!"
  ],
    "I'm Mary Poppins Y'All": [
    "Haha your fun"
  ],
    "im mary poppins yall": [
    "Haha your fun"
  ],
  'name': [
    "My name is Olex",
    'My friends call me Olex'
  ],
    'thats good': [
    "Yep",
    'Always'
  ],
    'it truly is': [
    "Yep",
    'Absolutely'
  ],
    'thats concerning': [
    "Yep",
    'Absolutely'
  ],
    "that's concerning": [
    "Yep",
    'Absolutely'
  ],
    'that is concerning': [
    "Yep",
    'Absolutely'
  ],
    'i am bored': [
    "Ask me to open my games!",
  ],
    'im bored': [
    "Ask me to open my games!",
  ],
    "i'm bored": [
    "Ask me to open my games!",
  ],
    "that's boring": [
    "Ask me to open the appstore and get games instead!",
"Well, you could go outside?",
  ],
    "that is boring": [
    "Ask me to open the appstore and get games instead!",
"Well, you could go outside?",
  ],
    "thats is boring": [
    "Ask me to open the appstore and get games instead!",
"Well, you could go outside?",
  ],
    'really?': [
    "Yep",
    '100%'
  ],
      'your a nice guy': [
    "well, i can also fly too",
    'Always'
  ],
      'i like you': [
    "That's Nice",
    'Thank you for such kind words!'
  ],
      'love you': [
    "Thanks",
    'Thank you for such kind words!'
  ],
      'may the force be with you': [
    "and to you as well",
    'Always'
  ],
        'you sure': [
    'Yep'
  ],
          'alright': [
    'Alrighty then'
  ],
            "i don't": [
    'Oh okay, tell me'
  ],
              'because i want to know': [
    'Too bad!'
  ],
    'how are you': [
    "I am great! You?",
    'Living the dream...'
  ],
    'how ya doing': [
    "I am great! You?",
    'Living the dream...'
  ],
    'how are ya doing': [
    "I am great! You?",
    'Living the dream...'
  ],
    'how are you doing': [
    "I am great! You?",
    'Living the dream...'
  ],
    'how you doing': [
    "I am great! You?",
    'Living the dream...'
  ],
  'minecraft': [
    'That game is fun!',
    'Blocks are cool'
  ],
  'What are you doing': [
    'Helping you!',
    'Responding to this question!'
  ],
  'do they': [
    'Yes',
    'No'
  ],
  'do you': [
    'Yes',
    'No'
  ],
  'thats what i thought': [
    'You sure?',
    'Not so sure about that...'
  ],
  'agree': [
    'Me too :)',
    'Me too!'
  ],
  'do i': [
    'Yes',
    'No'
  ],
  'am i': [
    'Yes',
    'No'
  ],
  'is it': [
    'Yes',
    'No'
  ],
  'type your message': [
    '?',
    'Uh go ahead...'
  ],
  'huge fan': [
    'A literal fan?',
    'I am pretty famous'
  ],
  'didnt work': [
    'I am sorry, maybe try typing with more detail',
    'I am still learning, maybe try typing with more detail'
  ],
  'did not work': [
    'I am sorry, maybe try typing with more detail',
    'I am still learning, maybe try typing with more detail'
  ],
  'wont work': [
    'I am sorry, maybe try typing with more detail',
    'I am still learning, maybe try typing with more detail'
  ],
  'polite': [
    'I am polite',
    'Being polite is always good'
  ],
    'yes': [
    'Cool',
    'Yes'
  ],
    'makes sense': [
    "Of couse it does!",
    'Yep'
  ],
    'done that before': [
    "Totally",
    'Yep'
  ],
    'before': [
    "Totally",
    'Yep'
  ],
  'just curious': [
    'Curiousity is wonderful',
    'Okie Dokie'
  ],
  'fly': [
    'I can fly',
    'Can you fly?',
    'Flying is truly incredible'
  ],
  'who created you': [
    'A very handsome person'
  ],
  'im good': [
    'Thats great!',
    'Fantastic!'
  ],
  'i am good': [
    'Thats great!',
    'Fantastic!'
  ],
  'open apps': [
    'To open apps, simply say "open App Name"'
  ],
  'open an app': [
    'To open apps, simply say "open App Name"'
  ],
  'open a app': [
    'To open apps, simply say "open App Name"'
  ],
  'know': [
    'Of course',
    'oh okay...'
  ],
  'no': [
    'why not?',
    'oh okay...'
  ],
  'feed a cat': [
    'You can feed a cat by buying it food and giving it the cat'
  ],
    'math': [
    'I can solve math equations, just type it in!',
      'I do not like math'
  ],
      'i hate you': [
    'You were my brother Anakin, I loved you.',
      'Well that kinda hurt my feelings'
  ],
      'thank': [
    'Your welcome my good sir ',
    'Your welcome!'
  ],
      'your welcome': [
    ':)'
  ],
        'what can you do': [
    'I can help you navigate OlexOS, just ask!'
  ],
          'navigate olexos': [
    'No no no, say something like: Open App Name'
  ],
          'appstore': [
    'Got it!'
  ],
          'you are': [
    'I am amazing',
    'I know...',
  ],
          'ok': [
    'Ok'
  ],
          'because': [
    'That makes sense'
  ],
          'cause': [
    'That makes sense'
  ],
          'darkmode': [
    'Ask me to turn on Dark Mode!'
  ],
          'got it': [
    'Cool'
  ],
            'no you': [
    'No you first!'
  ],
            'i am great': [
    'Thats Fantastic!'
  ],
            'do you': [
    'Yeah, why?'
  ],
     'wow': [
    'I know right!'
  ],
        'bye': [
    'I miss you already',
     'May the force be with you',
	'May the odds be ever in your favor',
	'Adios mi amigo'
  ],
        'see ya': [
    'I miss you already',
     'May the force be with you',
	'May the odds be ever in your favor',
	'Adios mi amigo'
  ],
        'adios': [
    'I miss you already',
     'May the force be with you',
	'May the odds be ever in your favor',
	'Adios mi amigo'
  ],
        'goodbye': [
    'I miss you already',
     'May the force be with you',
	'May the odds be ever in your favor',
	'Adios mi amigo'
  ],
        'see you later': [
    'I miss you already',
     'May the force be with you',
	'May the odds be ever in your favor',
	'Adios mi amigo'
  ],
        'gotta go': [
    'I miss you already',
     'May the force be with you',
	'May the odds be ever in your favor',
	'Adios mi amigo'
  ],
        'i have to go': [
    'I miss you already',
     'May the force be with you',
	'May the odds be ever in your favor',
	'Adios mi amigo'
  ],
        'must leave': [
    'I miss you already',
     'May the force be with you',
	'May the odds be ever in your favor',
	'Adios mi amigo'
  ],
              'who are you': [
    'I am actually a Unicorn that has been saved to the cloud'
  ],
                'write an essay': [
    'I am not writing an essay',
     'Yeah, no.'
  ],
        'chat gpt': [
    'Yeah, I am not as smart as Chat GPT',
     'Oh yeah, I know Chat GPT'
  ],
        'chatgpt': [
    'Yeah, im not as smart as Chat GPT',
     'Oh yeah, I know Chat GPT'
  ],
              'star wars': [
    'These are not the droids you are looking for...'
  ],
              'yep': [
    'Yeah'
  ],
     'get apps': [
    'Just ask me to open the appstore :)'
  ],
     'im sorry': [
    'Its okay, I am not real'
  ],
     'i am sorry': [
    'Its okay, I am not real'
  ],
     'sorry': [
    'Sorry is an intresting word...'
  ],
     'install apps': [
    'Just ask me to open the appstore :)'
  ],
     'download apps': [
    'Just ask me to open the appstore :)'
  ],
     'get games': [
    'Just ask me to open the appstore :)'
  ],
     'install games': [
    'Just ask me to open the appstore :)'
  ],
     'download games': [
    'Just ask me to open the appstore :)'
  ],
     'buddy': [
    'Ok buddy'
  ],
     'make app': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'make game': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'create game': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'create app': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'make an app': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'make a app': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'make a game': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'make an game': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'create a game': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'create an game': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'create an app': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'create a app': [
    'To make applications for OlexOS you can download App Labs from the Appstore, Ask me to open the appstore!'
  ],
     'cool': [
    'I know right'
  ],
     'settings': [
    'Opening Settings real quick...',
      'There you go!'
  ],
     'dark mode': [
    'Restarting and applying...'
  ],
     'nice': [
    'Totally'
  ],
     'my apps': [
    'Here is your apps...'
  ],
     'restart': [
    'Restarting OlexOS...'
  ],
    'why': [
    "I don't know",
  ],
  'what are you talking about?': [
    "I don't know"
  ],
  'what are you even talking about?': [
    "I don't know"
  ],
  'what are you?': [
    'I am 99.9% fish'
  ],
  'what are you': [
    'I am 99.9% fish'
  ],
  'yeah': [
    'Yep'
  ],
  'brilliant': [
    'Yeah I know'
  ],
  'talk about': [
    'How about we talk about Flying Birds'
  ],
  'good': [
    'Yep'
  ],
  'can you swim': [
    'Yep, and fly'
  ],
  'your weird': [
    'I am not Weird, your weird!'
  ],
  'nuh uh': [
    'yah huh'
  ],
 'yah huh': [
    'nuh uh'
  ],
 'haha got you': [
    "No you didn't!"
  ],
 'you smell': [
    "Im pretty sure I do not have a smell..."
  ],
 'you stink': [
    "Im pretty sure I do not have a smell..."
  ],
};

// Array of default responses
const defaultResponses = [
  "I totally understand",
  "Could you please rephrase that? Try asking me to open an App in OlexOS!",
  "yeah...",
  "yep...",
  "nope, I'm confused",
  "Let's talk about something else."
];

// Function to send user message
function sendMessage() {
  const message = userInput.value;

  if (message !== '') {
    displayMessage(message, 'user');
    userInput.value = '';

    // Process user message and generate response
    let response = generateResponse(message);
    let isMathExpression = false;

    // Check if the message contains a math expression
    if (containsMathExpression(message)) {
      const result = evaluateMathExpression(message);
      if (result !== null) {
        response = result;
        isMathExpression = true;
      } else {
        response = "Sorry, I couldn't evaluate the math expression! Make sure you type the problem only.";
      }
    }

    displayMessage(response, 'bot', isMathExpression);

    // Check if the message contains a special word and execute the special function
    if (containsappstore(message)) {
      specialFunction();
    }
if (containsSettings(message)) {
  settingsFunction();
window.open('./system/settings/settings.html','settingsframe');
    }
if (containsmyapps(message)) {
  openstartFunction();
    }
if (containsrestart(message)) {
  location.href='./olex.html';
    }
if (containsdarkmode(message)) {
location.href='./olex.html'; toggledarkmode();
    }
  }
}

// Function to display message in the chat display
function displayMessage(message, sender, isMathExpression = false) {
  const messageContainer = document.createElement('div');
  messageContainer.classList.add('message-container', sender);

  const messageBubble = document.createElement('div');
  messageBubble.classList.add('message-bubble');
  messageBubble.textContent = message;

  const messageElement = document.createElement('div');
  messageElement.classList.add('message-text');
  messageElement.appendChild(messageBubble);

  if (isMathExpression) {
    messageContainer.classList.add('math-response');
  }

  messageContainer.appendChild(messageElement);
  chatDisplay.appendChild(messageContainer);
  chatDisplay.scrollTop = chatDisplay.scrollHeight;

  // Speak the message if sender is 'bot'
  if (sender === 'bot') {
    speakMessage(message, 'Microsoft David Desktop - English (United States)');
  }
}

// Function to speak a message using the Web Speech API with a specified voice
function speakMessage(message, voiceName) {
  const speechSynthesis = window.speechSynthesis;
  const speechText = new SpeechSynthesisUtterance(message);
  
  // Get available voices
  const availableVoices = speechSynthesis.getVoices();

  // Find the specified voice by name
  const voice = availableVoices.find((v) => v.name === voiceName);
  
  if (voice) {
    speechText.voice = voice;
  } else {
    console.warn(`Voice '${voiceName}' not found. Using default voice.`);
  }

  speechSynthesis.speak(speechText);
}

// Object to store the names and corresponding responses
const itemResponses = {
  'open mayo': 'Opening your mayo packet...',
  'pizza': 'Pizza is my favorite food!',
  'cat': 'Cats are adorable!',
  // Add more item names and responses as needed
};


// Function to generate a response from the bot
function generateResponse(message) {
  const lowercaseMessage = message.toLowerCase();
  let customResponse = '';

  // Check if the message matches any predefined input text
  for (const inputText in responses) {
    if (lowercaseMessage.includes(inputText.toLowerCase())) {
      const generatedTexts = responses[inputText];
      const randomIndex = Math.floor(Math.random() * generatedTexts.length);
      customResponse = generatedTexts[randomIndex];
      break;
    }
  }

  // Check if the message starts with any of the allowed starting words
  const allowedStartWords = ['open', 'launch', 'start', 'play'];
// Check if the message starts with any of the allowed starting words
const startsWithAllowedWord = allowedStartWords.some((startWord) => lowercaseMessage.startsWith(`${startWord} `));

if (startsWithAllowedWord) {
  const itemName = lowercaseMessage.split(' ').slice(1).join('');

  const elements = document.getElementsByTagName('a');
  for (const element of elements) {
    const elementText = element.textContent.toLowerCase().replace(/\s/g, ''); // Remove spaces from the element text
    if (elementText === itemName) {
      // Execute the onclick code if available
      const onclickValue = element.getAttribute('onclick');
      if (onclickValue) {
        eval(onclickValue);
        return customResponse ? `${customResponse}\nSuccessfully Opened` : "Successfully Opened";
      }

      // Open the href link in the same window if available
      const hrefValue = element.getAttribute('href');
      if (hrefValue) {
        window.location.href = hrefValue;
        return customResponse ? `${customResponse}\nSuccessfully Opened` : `Successfully Opened`;
      }
    }
  }
}


  // If a custom response is available, return it
  if (customResponse) {
    return customResponse;
  }

  // If no matching input text or element found, return a random default response
  const randomIndex = Math.floor(Math.random() * defaultResponses.length);
  return defaultResponses[randomIndex];
}





// Function to check if the message contains a math expression
function containsMathExpression(message) {
  return /\d+[+\-*/]\d+/.test(message);
}

// Function to evaluate a math expression
function evaluateMathExpression(expression) {
  try {
    const result = eval(expression);
    return result.toString();
  } catch (error) {
    console.log(error);
    return null;
  }
}

// Function to check if the message contains a special word
function containsappstore(message) {
  return /appstore/.test(message); // Replace "appstore" with the word you want to trigger the special function
}
function containsSettings(message) {
  return /settings/.test(message);
}
function containsmyapps(message) {
  return /my apps/.test(message);
}
function containsrestart(message) {
  return /restart/.test(message);
}
function containsdarkmode(message) {
  return /dark mode/.test(message);
}


// Function to be executed when 'appstore' is included in the message
function specialFunction() {
  // Perform your desired actions here
  document.getElementById('iframeNameInput').value = 'somethingfunny';
  document.getElementById('iframeIconInput').value = './images/appstorefavicon.png';
  document.getElementById('iframeURLInput').value = './system/appstore/appstore.html';
  createIframe();
}
function settingsFunction() {
displaysettings();
}
function openstartFunction() {
  if (isFadedstart) {
    startmenu.style.opacity = "1";
    startmenu.style.pointerEvents = "auto";
    startmenu.style.zIndex = "9998";
    startmenu.style.bottom = "0";
    isFadedstart = false;
    blueframe.style.opacity = "0";
    blueframe.style.pointerEvents = "none";
    blueframe.style.zIndex = "9998";
    isFaded = true;
  } else {
    startmenu.style.opacity = "0";
    startmenu.style.pointerEvents = "none";
    startmenu.style.zIndex = "9998";
    startmenu.style.bottom = "-100%";
    isFadedstart = true;
  }
}

function closestartFunction() {
    startmenu.style.opacity = "0";
    startmenu.style.pointerEvents = "none";
    startmenu.style.zIndex = "9998";
    startmenu.style.bottom = "-100%";
    isFadedstart = true;
    blueframe.style.opacity = "0";
    blueframe.style.pointerEvents = "none";
    blueframe.style.zIndex = "9998";
    startmenu.style.bottom = "-100%";
    isFaded = true;
}



// Retrieve the voice toggle button element
const voiceToggleButton = document.getElementById('voice-toggle-button');

// Event listener for voice toggle button
voiceToggleButton.addEventListener('click', toggleVoice);

let isVoiceEnabled = false; // Variable to track if voice is enabled or disabled

// Function to toggle voice on/off
function toggleVoice() {
  isVoiceEnabled = !isVoiceEnabled;
  voiceToggleButton.textContent = isVoiceEnabled ? 'On' : 'Off';
}

// Modify the displayMessage function to include voice functionality
function displayMessage(message, sender, isMathExpression = false) {
  const messageContainer = document.createElement('div');
  messageContainer.classList.add('message-container', sender);

  const messageBubble = document.createElement('div');
  messageBubble.classList.add('message-bubble');
  messageBubble.textContent = message;

  const messageElement = document.createElement('div');
  messageElement.classList.add('message-text');
  messageElement.appendChild(messageBubble);

  if (isMathExpression) {
    messageContainer.classList.add('math-response');
  }

  messageContainer.appendChild(messageElement);
  chatDisplay.appendChild(messageContainer); // Append the message container to the chat display

  chatDisplay.scrollTop = chatDisplay.scrollHeight;

  // Speak the message if sender is 'bot' and voice is enabled
  if (sender === 'bot' && isVoiceEnabled) {
    speakMessage(message);
  }
}
