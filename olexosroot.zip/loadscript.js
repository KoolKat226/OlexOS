    function hasVisitedold() {
      return localStorage.getItem('visitedolexflow524') === 'true';
    }

    function hasVisited() {
      return localStorage.getItem('visitedolexflow525') === 'true';
    }

    // Function to set the visit status in localStorage
    function setVisitedStatus() {
      localStorage.setItem('visitedolexflow525', 'true');
    }

    function removeoldVisitedStatus() {
      localStorage.setItem('visitedolexflow524', 'false');
    }

    // Function to redirect the user
    function redirectToPage() {
      if (hasVisited()) {
        // Redirect to welcome.html if the user has already visited
        window.location.href = './olex.html';
      } else {
        // Redirect to page.html if it's their first visit
        window.location.href = './fresh.html';
        // Set the visit status to true
        setVisitedStatus();
      }
      if (hasVisitedold()) {
        // Redirect to welcome.html if the user has already visited
        window.location.href = './freshupdate.html';
        setVisitedStatus();
        removeoldVisitedStatus();
      }
    }

    // Call the redirection function on page load
    redirectToPage();