window.addEventListener("beforeunload", function(event) {
            event.preventDefault();
            event.returnValue = ""; // Required for Chrome and Firefox
            return ""; // Required for Safari
        });